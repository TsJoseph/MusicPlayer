package com.example.musictest;

import android.app.IntentService;
import android.content.Intent;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;
import java.io.File;
import java.io.IOException;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okio.BufferedSink;
import okio.Okio;
import okio.Sink;

//需要将下载的路径作为参数
public class DownMusicService extends IntentService {

    //下载路径，文件名
    public static final File PATH = Environment.getExternalStoragePublicDirectory("/Music");
    //文件名
    private String fileName;
    private String fileNameNew;

    protected void onHandleIntent(Intent intent) {

        //获取传进来的下载地址
        final String url = intent.getStringExtra("path");
        System.out.println(url);
        //获取到下载的文件名
        //先截取最后一个/之前的内容
        String str = url.substring(0,url.indexOf("/download"));
        //接着获取文件名
        fileName = str.substring(str.lastIndexOf("/")+1);
        //找第一个出现-的下标
        int index = fileName.indexOf("-");
        //如果没有找到说明文件名只有一小段
        //否则将-用空格代替,获取到文件名
        if(index == -1){
            fileNameNew = fileName;
        }else{
            String[] x = fileName.split("-");
            fileNameNew = x[0];
            for(int i=1; i<x.length; i++){
                fileNameNew = fileNameNew + " " + x[i];
            }
        }
        //开始下载的时间
        final long startTime = System.currentTimeMillis();
        Log.i("DOWNLOAD","startTime="+startTime);
        //用okhttp进行下载
        Request request = new Request.Builder().url(url).build();
        new OkHttpClient().newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                // 下载失败
                e.printStackTrace();
                //在主线程当中给出下载失败的提示
                Handler handler=new Handler(Looper.getMainLooper());
                handler.post(new Runnable(){
                    public void run(){
                        Toast.makeText(getApplicationContext(), "下载失败", Toast.LENGTH_LONG).show();
                    }
                });
            }
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                Sink sink = null;
                BufferedSink bufferedSink = null;
                try {
                    //在music目录下创建下载的新文件
                    File dest = new File(PATH, fileNameNew + ".mp3");
                    sink = Okio.sink(dest);
                    bufferedSink = Okio.buffer(sink);
                    bufferedSink.writeAll(response.body().source());
                    //关闭打开的文件
                    bufferedSink.close();
                    Log.i("DOWNLOAD", "totalTime=" + (System.currentTimeMillis() - startTime));
                    //给出下载成功的提示
                    Handler handler = new Handler(Looper.getMainLooper());
                    handler.post(new Runnable() {
                        public void run() {
                            Toast.makeText(getApplicationContext(), "下载成功!", Toast.LENGTH_LONG).show();
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                    Handler handler = new Handler(Looper.getMainLooper());
                    handler.post(new Runnable() {
                        public void run() {
                            Toast.makeText(getApplicationContext(), "下载失败!", Toast.LENGTH_LONG).show();
                        }
                    });
                } finally {
                    if (bufferedSink != null) {
                        bufferedSink.close();
                    }
                }
            }
        });
        //下载完之后回到主活动
        Intent intentNew = new Intent(DownMusicService.this, MainActivity.class);
        intentNew.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK );
        startActivity(intentNew);
    }
    public DownMusicService() {
        super("");

    }
}