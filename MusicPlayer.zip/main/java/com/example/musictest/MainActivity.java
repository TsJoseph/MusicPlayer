package com.example.musictest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileDescriptor;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    //获取音乐列表
    private List<Music> musicList  = new ArrayList<>();
    //音乐进度
    private TextView start;
    //总时长
    int total;
    private TextView end;
    //播放状态
    private SeekBar seekBar;
    private boolean isStop = true;
    private Button play;
    private MediaPlayer mediaPlayer;
    //用于存取assets目录下所有文件的文件名
    //private String[] arr;
    private String[] brr = new String[20];
    //用于存取所有音频文件的文件名
    //private String[] music = new String[10];
    //用于记录当前乐曲在数组中的下标
    private int location = 0;
    //切换音乐
    private int length = 1;
    //上一首
    private Button previous;
    //下一首
    private Button next;
    //音乐名
    private TextView music_name;
    //创建线程
    private Thread myThread;
    private MyRunnable myRunnable;
    //第一次执行
    private int firstTime = 0;
    //判断是否是本地歌曲
    private int[] native_song = new int[20];
    //获取music路径
    public static final File PATH = Environment.getExternalStoragePublicDirectory("/Music");
    private File[] files;
    public static final File MUSIC_PATH = new File(String.valueOf(PATH));
    private int index;

    //运用Handler中的handleMessage方法接收service传递的音乐播放进度信息
    private Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            // 将SeekBar位置设置到当前播放位置，
            // msg.arg1是service传过来的音乐播放进度信息,将其设置为进度条进度
            switch (msg.what) {
                case 1:
                    //将进度时间其转为mm:ss时间格式,显示在进度框中
                    //如果等于音乐最大长度则说明播放结束,关掉线程
                    if(msg.arg1 == mediaPlayer.getDuration()) {
                        myRunnable.shutDown();
                    }
                    seekBar.setProgress(msg.arg1);
                    start.setText(new SimpleDateFormat("mm:ss", Locale.getDefault()).format(new Date(msg.arg1)));
                    return false;
                default:
                    break;
            }
            return true;
        }
    });

//实行Runnable接口
    class MyRunnable implements Runnable {
        boolean flag = true;
        @Override
        public void run() {
            //判断当前播放位置是否小于总时长,如果不是则不断的往主线程发送消息
            while(flag) {
                try {
                    //每50毫秒执行一次
                    Thread.sleep(50);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                Message msg = new Message();
                msg.what = 1;
                //设置进度条当前位置为音频播放位置
                msg.arg1 = mediaPlayer.getCurrentPosition();
                //主线程中处理数据
                handler.sendMessage(msg);
            }
        }
        //用于关掉线程
        public void shutDown() {
            flag = false;
        }
    }

//构造函数
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d("MainActivity","onCreate()");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button refresh = (Button)findViewById(R.id.refresh);

        //获取assets目录下所有文件的文件名
//        try {
////            arr = MainActivity.this.getAssets().list("");
////        } catch (IOException e) {
////            e.printStackTrace();
////        }
    /////
        //获取Music文件的二级目录
        //获取music目录下所有的文件,存在file数组中
        files = MUSIC_PATH.listFiles();
        index = 0;
        int file_length = files.length;   //获取文件的个数
//        if (file_length > 0) {                   //当数组不空时，遍历数组文件
//            for (File file : files) {
//                brr[index] = file.getName();  //将数组文件的文件名存入数组
//                index++;
//                if(index == files.length -1 )
//                    break;
//            }
//        }

//        grave.mp3
//        ashore.mp3
//        into the unknown.mp3
//        sister riskat lawal.mp3
//        world of snow.mp3
//        for(int i=0;i < index;i++) {
//            Log.d("MainActivity","文件名:"+brr[i]);
//        }
        //测试
        brr[index] = "grave.mp3";
        index++;
        brr[index] = "ashore.mp3";
        index++;//index = 5
        brr[index] = "boana.mp3";
        index++;
        brr[index] = "ces.mp3";
        index++;
        brr[index] = "seven.mp3";
        index++;

        for(int i=0;i < index;i++) {
            Log.d("MainActivity","文件名:"+brr[i]);
        }

        Log.d("MainActivity","index:"+index);
        Log.d("MainActivity","file_length:"+file_length);


        /////
        //筛选出所有音频文件的文件名
        //音乐数组长度为num
//        int num = 0;
//        for(int i=0;i<arr.length;i++) {
//            //正则表达式匹配以mp3结尾的文件名
//            if(arr[i].matches(".*\\.mp3$")) {
//                music[num] = arr[i];
//                num++;
//            }
//        }

        length = index;  //length = 5
        Log.d("MainActivity","length:"+length);
        //初始化下载状态数组
        for(int i = 0;i<(file_length - 1);i++) {
            native_song[i] = 1;
        }
        for(int i = (file_length - 1);i<20;i++) {
            native_song[i] = 0;
        }
        //打印文件名
        for(int i=0;i < 10;i++) {
            Log.d("MainActivity","naive_song:"+ i + native_song[i]);
        }

        //初始化控件
        start = (TextView)findViewById(R.id.start_time);
        end = (TextView)findViewById(R.id.end_time);
        seekBar = (SeekBar)findViewById(R.id.seekbar);
        play = (Button) findViewById(R.id.play);
        previous = (Button) findViewById(R.id.previous);
        next = (Button) findViewById(R.id.next);
        music_name = (TextView)findViewById(R.id.music);

 //ListView显示音乐列表
        initMusic();
        MusicAdapter adapter = new MusicAdapter(MainActivity.this,R.layout.music_item,musicList);
        ListView listView = (ListView) findViewById(R.id.list_view);
        listView.setAdapter(adapter);

//第一次打开app时歌曲的初始化
//音乐存放在SD卡里面，访问SD卡的权限是危险权限要在访问中动态申请,初始化musicPlayer
        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        } else {
            //初始化MediaPlayer
            mediaPlayer = new MediaPlayer();
            iniMediaPlayer();
        }

 //设置进度条最大长度为音频时长
        total = mediaPlayer.getDuration();
        seekBar.setMax(total);
//初始化进度文本框
        end.setText(new SimpleDateFormat("mm:ss", Locale.getDefault()).format(new Date(mediaPlayer.getDuration())));
        start.setText(new SimpleDateFormat("mm:ss", Locale.getDefault()).format(new Date(0)));
        music_name.setText(brr[location]);

 //listView点击响应函数
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                if(firstTime != 0) {
                    myRunnable.shutDown();
                }
                Music musicId = musicList.get(position);
                String name = musicId.getMusicName();
                //找到该音乐在音乐列表里的位置
                for(int i=0;i<length;i++) {
                    if(name.equals(brr[i])) {
                        location = i;
                        break;
                    }
                }
                Log.d("MainActivity","listview_location:"+location);
                Log.d("MainActivity","native_song:"+native_song[location]);
            //先将mediaPlayer置为空
                mediaPlayer.reset();
                Log.d("MainActivity","match_location:"+location);

                if(native_song[location] == 1) {

                    //重新初始化控件和音乐信息
                    iniMediaPlayer();
                    total = mediaPlayer.getDuration();
                    seekBar.setMax(total);
                    //初始化进度文本框
                    end.setText(new SimpleDateFormat("mm:ss", Locale.getDefault()).format(new Date(total)));
                    start.setText(new SimpleDateFormat("mm:ss", Locale.getDefault()).format(new Date(0)));
                    music_name.setText(brr[location]);
                    mediaPlayer.start();

                    myRunnable = new MyRunnable();
                    myThread = new Thread(myRunnable);
                    myThread.start();
                    //说明已经不是第一次执行了
                    //第二次执行开始每次执行之前都需要停止之前的线程
                    firstTime++;
                    isStop = false;
                    play.setText("暂停");
                } else {

                    String pathNew = null;
                    //获取文件名
                    String newName = name.substring(0,(name.length() - 4));
                    //将空格用-代替
                    int index2 = newName.indexOf(" ");
                    if(index2 == -1){
                        pathNew = newName;
                    }else{
                        String[] x = newName.split(" ");
                        pathNew = x[0];
                        for(int i=1; i<x.length;i++) {
                            pathNew = pathNew + "-" + x[i];
                        }
                    }
                    System.out.println(pathNew);
                    //下载地址
                    String pathLast = "https://freemusicarchive.org/track/" + pathNew +"/download";
                    System.out.println(pathLast);
                    //启动服务进行下载
                    Intent intent = new Intent(MainActivity.this, DownMusicService.class);
                    intent.putExtra("path",pathLast);
                    startService(intent);
                    files = MUSIC_PATH.listFiles();
                }

            }
        });

//播放play的响应函数
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //如果在播放则暂停，不在播放则播放
                if (isStop) {
                    play.setText("暂停");
                    //开始播放音乐
                    mediaPlayer.start();
                    if(firstTime == 0) {
                        myRunnable = new MyRunnable();
                        myThread = new Thread(myRunnable);
                        myThread.start();
                    }
                    firstTime++;
                    isStop = false;
                } else {
                    //暂停
                    mediaPlayer.pause();
                    isStop = true;
                    play.setText("播放");
                }
            }
        });

//下一首歌曲
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(firstTime != 0) {
                    myRunnable.shutDown();
                }
                //播放下一首歌曲
                location = (location + 1) % length;
                Log.d("MainActivity","next.location:"+location);
                mediaPlayer.reset();
    //重新初始化
                iniMediaPlayer();
                total = mediaPlayer.getDuration();
                seekBar.setMax(total);
    //初始化进度文本框
                end.setText(new SimpleDateFormat("mm:ss", Locale.getDefault()).format(new Date(total)));
                start.setText(new SimpleDateFormat("mm:ss", Locale.getDefault()).format(new Date(0)));
                music_name.setText(brr[location]);
                mediaPlayer.start();

                myRunnable = new MyRunnable();
                myThread = new Thread(myRunnable);
                myThread.start();
                firstTime++;
                isStop = false;
                play.setText("暂停");
            }
        });

//上一首歌曲
        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(firstTime != 0) {
                    myRunnable.shutDown();
                }

                location = location - 1;
                if(location < 0) {
                    location = length-1;
                }

                mediaPlayer.reset();
                iniMediaPlayer();
                //重新初始化
                total = mediaPlayer.getDuration();
                seekBar.setMax(total);
                //初始化进度文本框
                end.setText(new SimpleDateFormat("mm:ss", Locale.getDefault()).format(new Date(total)));
                start.setText(new SimpleDateFormat("mm:ss", Locale.getDefault()).format(new Date(0)));
                music_name.setText(brr[location]);
                mediaPlayer.start();

                myRunnable = new MyRunnable();
                myThread = new Thread(myRunnable);
                myThread.start();

                firstTime++;
                isStop = false;
                play.setText("暂停");
            }
        });

//设置进度条的状态监听器
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                if(b) {
                    mediaPlayer.seekTo(seekBar.getProgress());
                }
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                mediaPlayer.seekTo(seekBar.getProgress());
            }
        });
//刷新
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                files = MUSIC_PATH.listFiles();
                index = 0;
                int file_length = files.length;
                brr[index] = "grave.mp3";
                index++;
                brr[index] = "ashore.mp3";
                index++;//index = 5
                brr[index] = "boana.mp3";
                index++;
                brr[index] = "ces.mp3";
                index++;
                brr[index] = "seven.mp3";
                index++;
                for(int i=0;i < index;i++) {
                    Log.d("MainActivity","文件名:"+brr[i]);
                }
                //测试
                //brr[index] = "elayun.mp3";
                //index++;//index = 5

                Log.d("MainActivity","index:"+index);
                Log.d("MainActivity","file_length:"+file_length);


                /////
                //筛选出所有音频文件的文件名
                //音乐数组长度为num
//        int num = 0;
//        for(int i=0;i<arr.length;i++) {
//            //正则表达式匹配以mp3结尾的文件名
//            if(arr[i].matches(".*\\.mp3$")) {
//                music[num] = arr[i];
//                num++;
//            }
//        }

                length = index;  //length = 5
                Log.d("MainActivity","length:"+length);
                //初始化下载状态数组
                for(int i = 0;i<(file_length - 1);i++) {
                    native_song[i] = 1;
                }
                for(int i = (file_length - 1);i<20;i++) {
                    native_song[i] = 0;
                }
            }
        });
    }

    //音乐列表的初始化函数
    private void initMusic() {
        musicList.clear();
        Music musicItem1 = new Music("grave.mp3");
        musicList.add(musicItem1);
        Music musicItem2 = new Music("ashore.mp3");
        musicList.add(musicItem2);
        Music musicItem3 = new Music("boana.mp3");
        musicList.add(musicItem3);
        Music musicItem4 = new Music("ces.mp3");
        musicList.add(musicItem4);
        // Music musicItem5 = new Music("heart science no beats.mp3");
        Music musicItem5 = new Music("seven.mp3");
        musicList.add(musicItem5);

    }

    //权限请求返回结果
    @Override
    public void onRequestPermissionsResult ( int requestCode, @NonNull String[] permissions,
                                             @NonNull int[] grantResults){
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    iniMediaPlayer();
                } else {
                    Toast.makeText(this, "拒绝权限将无法使用该程序", Toast.LENGTH_SHORT).show();
                    finish();
                }
                break;
            default:
                break;
        }
    }

    //初始化播放器
    private void iniMediaPlayer () {
        try {
            //获取assets目录路径
            //AssetManager am = getAssets();
            //AssetFileDescriptor afd = am.openFd(music[location]);
            //获取FileDescriptor
            //FileDescriptor fd = afd.getFileDescriptor();
            //mediaPlayer.setDataSource(fd,afd.getStartOffset(),afd.getLength());
            //mediaPlayer.prepare();
            mediaPlayer.setDataSource(files[location].getPath());
            mediaPlayer.prepare();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //销毁活动的时候将多媒体播放器也销毁
    @Override
    protected void onDestroy () {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
        }
    }

}